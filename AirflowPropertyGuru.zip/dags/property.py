from datetime import datetime
from airflow import DAG
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.operators.bash_operator import BashOperator

with DAG('property', start_date=datetime(2023, 7, 17),
         schedule_interval='@weekly', catchup=False) as dag:
    
    s3_sensor = S3KeySensor(
        task_id = 'search_file_check',
        bucket_name = 'my-search-filter-buk',
        bucket_key = 'search.csv',
        aws_conn_id = 'aws_conn'
    )

    curl_command = "curl -X POST http://172.22.0.5:5000/data"