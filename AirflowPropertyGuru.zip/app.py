from flask import Flask
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import boto3
from bs4 import BeautifulSoup
import pandas
import time


app = Flask(__name__)

@app.post("/data")
def download_search_filter_fromS3():
    s3Client = boto3.client('s3')
    response = s3Client.get_object(Bucket='my-search-filter-buk', Key='search.csv')
    data = response['Body'].read()
    filter_string = data.decode('utf-8')
    print(filter_string)
    filter_list = filter_string.split(",")
    char = '@'
    n_filter_list = [search for search in filter_list if char not in search]
    print(n_filter_list)
    search_param(n_filter_list)
    return "success"

def search_param(filter_list):
    url_builder_mapping = {
        "East-West Line": "CG1&MRT_STATIONS[]=DT35&MRT_STATIONS[]=CG2&MRT_STATIONS[]=CP1&MRT_STATIONS[]=CR5&MRT_STATIONS[]=EW1&MRT_STATIONS[]=DT32&MRT_STATIONS[]=EW2&MRT_STATIONS[]=EW3&MRT_STATIONS[]=CG&MRT_STATIONS[]=EW4&MRT_STATIONS[]=EW5&MRT_STATIONS[]=EW6&MRT_STATIONS[]=EW7&MRT_STATIONS[]=CC9&MRT_STATIONS[]=EW8&MRT_STATIONS[]=EW9&MRT_STATIONS[]=EW10&MRT_STATIONS[]=EW11&MRT_STATIONS[]=DT14&MRT_STATIONS[]=EW12&MRT_STATIONS[]=EW13&MRT_STATIONS[]=NS25&MRT_STATIONS[]=EW14&MRT_STATIONS[]=NS26&MRT_STATIONS[]=EW15&MRT_STATIONS[]=EW16&MRT_STATIONS[]=NE3&MRT_STATIONS[]=TE17&MRT_STATIONS[]=EW17&MRT_STATIONS[]=EW18&MRT_STATIONS[]=EW19&MRT_STATIONS[]=EW20&MRT_STATIONS[]=CC22&MRT_STATIONS[]=EW21&MRT_STATIONS[]=EW22&MRT_STATIONS[]=EW23&MRT_STATIONS[]=EW24&MRT_STATIONS[]=JE5&MRT_STATIONS[]=NS1&MRT_STATIONS[]=EW25&MRT_STATIONS[]=EW26&MRT_STATIONS[]=EW27&MRT_STATIONS[]=JS8&MRT_STATIONS[]=EW28&MRT_STATIONS[]=EW29&MRT_STATIONS[]=EW30&MRT_STATIONS[]=EW31&MRT_STATIONS[]=EW32&MRT_STATIONS[]=EW33&freetext=CG1/DT35+Expo+MRT,CG2+Changi+Airport+MRT,EW1/CP1/CR5+Pasir+Ris+MRT,EW2/DT32+Tampines+MRT,EW3+Simei+MRT,EW4/CG+Tanah+Merah+MRT,EW5+Bedok+MRT,EW6+Kembangan+MRT,EW7+Eunos+MRT,EW8/CC9+Paya+Lebar+MRT,EW9+Aljunied+MRT,EW10+Kallang+MRT,EW11+Lavender+MRT,EW12/DT14+Bugis+MRT,EW13/NS25+City+Hall+MRT,EW14/NS26+Raffles+Place+MRT,EW15+Tanjong+Pagar+MRT,EW16/NE3/TE17+Outram+Park+MRT,EW17+Tiong+Bahru+MRT,EW18+Redhill+MRT,EW19+Queenstown+MRT,EW20+Commonwealth+MRT,EW21/CC22+Buona+Vista+MRT,EW22+Dover+MRT,EW23+Clementi+MRT,EW24/NS1/JE5+Jurong+East+MRT,EW25+Chinese+Garden+MRT,EW26+Lakeside+MRT,EW27/JS8+Boon+Lay+MRT,EW28+Pioneer+MRT,EW29+Joo+Koon+MRT,EW30+Gul+Circle+MRT,EW31+Tuas+Crescent+MRT,EW32+Tuas+West+Road+MRT,EW33+Tuas+Link+MRT",
        "North-South Line": "EW24%2FNS1%2FJE5+Jurong+East+MRT%2C+NS2+Bukit+Batok+MRT%2C+NS3+Bukit+Gombak+MRT%2C+BP1%2FNS4%2FJS1+Choa+Chu+Kang+LRT%2C+JS1%2FNS4%2FBP1+Choa+Chu+Kang+MRT%2C+NS5+Yew+Tee+MRT%2C+NS7+Kranji+MRT%2C+NS8+Marsiling+MRT%2C+NS9%2FTE2+Woodlands+MRT%2C+NS10+Admiralty+MRT%2C+NS11+Sembawang+MRT%2C+NS12+Canberra+MRT%2C+NS13+Yishun+MRT%2C+NS14+Khatib+MRT%2C+NS15+Yio+Chu+Kang+MRT%2C+CR11%2FNS16+Ang+Mo+Kio+MRT%2C+CC15%2FNS17+Bishan+MRT%2C+NS18+Braddell+MRT%2C+NS19+Toa+Payoh+MRT%2C+NS20+Novena+MRT%2C+DT11%2FNS21+Newton+MRT%2C+NS22%2FTE14+Orchard+MRT%2C+NS23+Somerset+MRT%2C+CC1%2FNS24%2FNE6+Dhoby+Ghaut+MRT%2C+EW13%2FNS25+City+Hall+MRT%2C+EW14%2FNS26+Raffles+Place+MRT%2C+CE2%2FNS27%2FTE20+Marina+Bay+MRT%2C+NS28+Marina+South+Pier+MRT&market=residential&MRT_STATIONS%5B%5D=EW24&MRT_STATIONS%5B%5D=JE5&MRT_STATIONS%5B%5D=NS1&MRT_STATIONS%5B%5D=NS2&MRT_STATIONS%5B%5D=NS3&MRT_STATIONS%5B%5D=BP1&MRT_STATIONS%5B%5D=JS1&MRT_STATIONS%5B%5D=NS4&MRT_STATIONS%5B%5D=NS5&MRT_STATIONS%5B%5D=NS7&MRT_STATIONS%5B%5D=NS8&MRT_STATIONS%5B%5D=NS9&MRT_STATIONS%5B%5D=TE2&MRT_STATIONS%5B%5D=NS10&MRT_STATIONS%5B%5D=NS11&MRT_STATIONS%5B%5D=NS12&MRT_STATIONS%5B%5D=NS13&MRT_STATIONS%5B%5D=NS14&MRT_STATIONS%5B%5D=NS15&MRT_STATIONS%5B%5D=CR11&MRT_STATIONS%5B%5D=NS16&MRT_STATIONS%5B%5D=CC15&MRT_STATIONS%5B%5D=NS17&MRT_STATIONS%5B%5D=NS18&MRT_STATIONS%5B%5D=NS19&MRT_STATIONS%5B%5D=NS20&MRT_STATIONS%5B%5D=DT11&MRT_STATIONS%5B%5D=NS21&MRT_STATIONS%5B%5D=NS22&MRT_STATIONS%5B%5D=TE14&MRT_STATIONS%5B%5D=NS23&MRT_STATIONS%5B%5D=CC1&MRT_STATIONS%5B%5D=NE6&MRT_STATIONS%5B%5D=NS24&MRT_STATIONS%5B%5D=EW13&MRT_STATIONS%5B%5D=NS25&MRT_STATIONS%5B%5D=EW14&MRT_STATIONS%5B%5D=NS26&MRT_STATIONS%5B%5D=CE2&MRT_STATIONS%5B%5D=NS27&MRT_STATIONS%5B%5D=TE20&MRT_STATIONS%5B%5D=NS28",
        "North-East Line" : "CC29&MRT_STATIONS[]=NE1&MRT_STATIONS[]=EW16&MRT_STATIONS[]=NE3&MRT_STATIONS[]=TE17&MRT_STATIONS[]=DT19&MRT_STATIONS[]=NE4&MRT_STATIONS[]=NE5&MRT_STATIONS[]=CC1&MRT_STATIONS[]=NE6&MRT_STATIONS[]=NS24&MRT_STATIONS[]=DT12&MRT_STATIONS[]=NE7&MRT_STATIONS[]=NE8&MRT_STATIONS[]=NE9&MRT_STATIONS[]=NE10&MRT_STATIONS[]=NE11&MRT_STATIONS[]=CC13&MRT_STATIONS[]=NE12&MRT_STATIONS[]=NE13&MRT_STATIONS[]=CR8&MRT_STATIONS[]=NE14&MRT_STATIONS[]=NE15&MRT_STATIONS[]=NE16&MRT_STATIONS[]=STC&MRT_STATIONS[]=CP4&MRT_STATIONS[]=NE17&MRT_STATIONS[]=PTC&freetext=NE1/CC29+HarbourFront+MRT,EW16/NE3/TE17+Outram+Park+MRT,NE4/DT19+Chinatown+MRT,NE5+Clarke+Quay+MRT,NS24/NE6/CC1+Dhoby+Ghaut+MRT,NE7/DT12+Little+India+MRT,NE8+Farrer+Park+MRT,NE9+Boon+Keng+MRT,NE10+Potong+Pasir+MRT,NE11+Woodleigh+MRT,NE12/CC13+Serangoon+MRT,NE13+Kovan+MRT,NE14/CR8+Hougang+MRT,NE15+Buangkok+MRT,NE16/STC+Sengkang+MRT,NE17/PTC/CP4+Punggol+MRT",
        "Circle Line" : "CC1&MRT_STATIONS[]=NE6&MRT_STATIONS[]=NS24&MRT_STATIONS[]=CC2&MRT_STATIONS[]=CC3&MRT_STATIONS[]=CC4&MRT_STATIONS[]=DT15&MRT_STATIONS[]=CC5&MRT_STATIONS[]=CC6&MRT_STATIONS[]=CC7&MRT_STATIONS[]=CC8&MRT_STATIONS[]=CC9&MRT_STATIONS[]=EW8&MRT_STATIONS[]=CC10&MRT_STATIONS[]=DT26&MRT_STATIONS[]=CC11&MRT_STATIONS[]=CC12&MRT_STATIONS[]=CC13&MRT_STATIONS[]=NE12&MRT_STATIONS[]=CC14&MRT_STATIONS[]=CC15&MRT_STATIONS[]=NS17&MRT_STATIONS[]=CC16&MRT_STATIONS[]=CC17&MRT_STATIONS[]=TE9&MRT_STATIONS[]=CC19&MRT_STATIONS[]=DT9&MRT_STATIONS[]=CC20&MRT_STATIONS[]=CC21&MRT_STATIONS[]=CC22&MRT_STATIONS[]=EW21&MRT_STATIONS[]=CC23&MRT_STATIONS[]=CC24&MRT_STATIONS[]=CC25&MRT_STATIONS[]=CC26&MRT_STATIONS[]=CC27&MRT_STATIONS[]=CC28&MRT_STATIONS[]=CC29&MRT_STATIONS[]=NE1&MRT_STATIONS[]=CE1&MRT_STATIONS[]=DT16&MRT_STATIONS[] = CE2 &MRT_STATIONS[] = NS27 &MRT_STATIONS[]=TE20&freetext=NS24/NE6/CC1+Dhoby+Ghaut+MRT,CC2+Bras+Basah+MRT,CC3+Esplanade+MRT,CC4/DT15+Promenade+MRT,CC5+Nicoll+Highway+MRT,CC6+Stadium+MRT,CC7+Mountbatten+MRT,CC8+Dakota+MRT,EW8/CC9+Paya+Lebar+MRT,CC10/DT26+MacPherson+MRT,CC11+Tai+Seng+MRT,CC12+Bartley+MRT,NE12/CC13+Serangoon+MRT,CC14+Lorong+Chuan+MRT,NS17/CC15+Bishan+MRT,CC16+Marymount+MRT,CC17/TE9+Caldecott+MRT,CC19/DT9+Botanic+Gardens+MRT,CC20+Farrer+Road+MRT,CC21+Holland+Village+MRT,EW21/CC22+Buona+Vista+MRT,CC23+One-North+MRT,CC24+Kent+Ridge+MRT,CC25+Haw+Par+Villa+MRT,CC26+Pasir+Panjang+MRT,CC27+Labrador+Park+MRT,CC28+Telok+Blangah+MRT,NE1/CC29+HarbourFront+MRT,CE1/DT16+Bayfront+MRT,NS27/CE2/TE20+Marina+Bay+MRT",
        "Downtown Line" : "BP6&MRT_STATIONS[]=DT1&MRT_STATIONS[]=DT2&MRT_STATIONS[]=DT3&MRT_STATIONS[]=DT5&MRT_STATIONS[]=DT6&MRT_STATIONS[]=DT7&MRT_STATIONS[]=DT8&MRT_STATIONS[]=CC19&MRT_STATIONS[]=DT9&MRT_STATIONS[]=DT10&MRT_STATIONS[]=TE11&MRT_STATIONS[]=DT11&MRT_STATIONS[]=NS21&MRT_STATIONS[]=DT12&MRT_STATIONS[]=NE7&MRT_STATIONS[]=DT13&MRT_STATIONS[]=DT14&MRT_STATIONS[]=EW12&MRT_STATIONS[]=CC4&MRT_STATIONS[]=DT15&MRT_STATIONS[]=CE1&MRT_STATIONS[]=DT16&MRT_STATIONS[]=DT17&MRT_STATIONS[]=DT18&MRT_STATIONS[]=DT19&MRT_STATIONS[]=NE4&MRT_STATIONS[]=DT20&MRT_STATIONS[]=DT21&MRT_STATIONS[]=DT22&MRT_STATIONS[]=DT23&MRT_STATIONS[]=DT24&MRT_STATIONS[]=DT25&MRT_STATIONS[]=CC10&MRT_STATIONS[]=DT26&MRT_STATIONS[]=DT27&MRT_STATIONS[]=DT28&MRT_STATIONS[]=DT29&MRT_STATIONS[]=DT30&MRT_STATIONS[]=DT31&MRT_STATIONS[]=DT32&MRT_STATIONS[]=EW2&MRT_STATIONS[]=DT33&MRT_STATIONS[]=DT34&MRT_STATIONS[]=CG1&MRT_STATIONS[]=DT35&freetext=DT1/BP6+Bukit+Panjang+MRT,DT2+Cashew+MRT,DT3+Hillview+MRT,DT5+Beauty+World+MRT,DT6+King+Albert+Park+MRT,DT7+Sixth+Avenue+MRT,DT8+Tan+Kah+Kee+MRT,CC19/DT9+Botanic+Gardens+MRT,DT10/TE11+Stevens+MRT,NS21/DT11+Newton+MRT,NE7/DT12+Little+India+MRT,DT13+Rochor+MRT,EW12/DT14+Bugis+MRT,CC4/DT15+Promenade+MRT,CE1/DT16+Bayfront+MRT,DT17+Downtown+MRT,DT18+Telok+Ayer+MRT,NE4/DT19+Chinatown+MRT,DT20+Fort+Canning+MRT,DT21+Bencoolen+MRT,DT22+Jalan+Besar+MRT,DT23+Bendemeer+MRT,DT24+Geylang+Bahru+MRT,DT25+Mattar+MRT,CC10/DT26+MacPherson+MRT,DT27+Ubi+MRT,DT28+Kaki+Bukit+MRT,DT29+Bedok+North+MRT,DT30+Bedok+Reservoir+MRT,DT31+Tampines+West+MRT,EW2/DT32+Tampines+MRT,DT33+Tampines+East+MRT,DT34+Upper+Changi+MRT,CG1/DT35+Expo+MRT"
                        }
    search_param = ''
    for filter in filter_list:
        if filter in url_builder_mapping.keys():
            search_param = search_param + url_builder_mapping[filter]

    is_room_flag = ["True", "False"]
    for room_filter in filter_list:
        if room_filter in is_room_flag:
            is_room = room_filter

    is_room = room_filter

    print(f'Inside extract_data{search_param}')
    for i in range(1,11):
        time.sleep(20)
        print(is_room)
        list_to_export = extract_data(search_param, i, is_room)
        export_data(list_to_export)

    upload_s3()


def extract_data(search_param, i, is_room):
    # create chrome dirver using selenium
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--ignore-ssl-errors=yes')
    options.add_argument('--ignore-certificate-errors')
    options.add_argument('--disable-gpu')
    options.add_argument('user-agent=Chrome/113.0')
    #driver = webdriver.Chrome("/Users/moeamanda/Downloads/chromedriver_mac_arm64/chromedriver",options=options)
    driver = webdriver.Remote("http://selenium:4444/wd/hub", options=options)



    # URL with search filter
    search_filter = '&listing_type=rent&beds[]=-1&search=true'
    if is_room:
        url = f'https://www.propertyguru.com.sg/property-for-rent/{i}?freetext={search_param}{search_filter}'
        print(url)
        driver.get(url)
    else :
        url = f'https://www.propertyguru.com.sg/property-for-rent/{i}?freetext={search_param}'
        print(url)
        driver.get(url)
    try:
        element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//div[@class="listing-pagination"]')))
    finally:
        page_source = driver.page_source
        soup = BeautifulSoup(page_source, features='html.parser')
        item = soup.find_all('div', {"row"})
        item_listing = soup.find_all('div', {"class": "col-xs-12 col-sm-12 listing-description"})
        list_to_export = prepare_data(item_listing)
        driver.quit()
        return list_to_export






def prepare_data(item_listing):
    l = []
    for listing in item_listing:
        d = {}
        if len(listing.find_all("a", {"class": "nav-link"})):
            if (listing.find_all("a", {"class": "nav-link"})[0].text):
                d["Property Name"] = listing.find_all("a", {"class": "nav-link"})[0].text
            for address in listing.find_all("p", {"class": "listing-location ellipsis"}):
                d["Address"] = address.find("span").text
            for price in listing.find_all("ul", {"class": "listing-features"}):
                for price_list in listing.find_all("li", {"class": "list-price pull-left"}):
                    if (price.find("span", {"class": "currency"}) and price.find("span", {"class": "price"})):
                        d["Price"] = price.find("span", {"class": "price"}).text
                    # if (price.find("span", {"class": "currency"})):
                    # print(price.find("span", {"class": "period"}).text)
            if (listing.find("li", {"class": "listing-availability pull-left"})):
                d["Available Date"] = listing.find("li", {"class": "listing-availability pull-left"}).text

            for features in listing.find_all("ul", {"class": "listing-features pull-left"}):
                for rooms in listing.find_all("li", {"class": "listing-rooms pull-left"}):
                    if (features.find("span", {"class": "bed"})):
                        d["Bed"] = rooms.find("span", {"class": "bed"}).text
                    if (features.find("span", {"class": "bath"})):
                        d["Bath"] = rooms.find("span", {"class": "bath"}).text

            for dist_mrt in listing.find_all("ul", {"data-automation-id" : "listing-features-walk"}):
                if dist_mrt.find("li").text:
                    d["working_dist_mrt"] = dist_mrt.find("li").text



            for clear_both_list_property in listing.find_all("div", {"class": "clear-both listing-properties"}):
                '''for property_type in listing.find_all("ul", {"class":"listing-property-type"}):
                    for property_type_list in listing.find_all("li", {"class":""}):
                        if property_type_list.text:
                            print("**********"+property_type_list.text)'''

                for recency in listing.find_all("div",{"class":"listing-recency"}):
                    if recency.text:
                        d["time_posted"] = recency.text

        if (len(d) != 0):
            l.append(d)
    return l
    #export_data(l)


def export_data(l):
    df = pandas.DataFrame(l)
    print(df)
    df.to_csv("output.csv", mode='a')


def upload_s3():
    # get csv file in-memory
    s3 = boto3.client('s3')
    with open('output.csv', 'rb') as file:
        # put_object
        response = s3.put_object(
            Body=file,
            Bucket='my-extract-data-buk',
            Key='output.csv',
            ContentType='text/csv'
        )

    print(response)

#if __name__ == '__main__':
    #download_search_filter_fromS3()
