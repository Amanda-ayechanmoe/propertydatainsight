from extract_data import download_search_filter_fromS3
import csv
import boto3
import pandas as pd


def search_param_upload(filter_list):
    print(filter_list)
    filename = 'search.csv'
    with open(filename, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(filter_list)

    print (f"Data written to {filename} file.")
    upload_S3()

    # for filters in filter_list:
    #     d = {}
    #     if len(filters):
    #         d['filters'] = filters
    #
    #     if (len(d) != 0):
    #         l.append(d)

    # df = pd.DataFrame(l)
    # print(df)
    # df.to_csv('search.csv')
    #upload_S3()


def upload_S3():
    # Intilize interfaces
    s3Client = boto3.client('s3')

   # get csv file in-memory
    with open('search.csv', 'rb') as file:
        # put_object
        response = s3Client.put_object(
            Body=file,
            Bucket='my-search-filter-buk',
            Key='search.csv',
            ContentType='text/csv'
        )

    print(response)


