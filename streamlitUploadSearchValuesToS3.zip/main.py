import streamlit as st
#from extract_data import download_search_filter_fromS3
#from extract_data99co import extract_data
from upload_searchcriteria_to_S3 import search_param_upload
#from data_extract import download_search_filter_fromS3

st.set_page_config()

st.header("Search this for me")

with st.form(key='filter_form'):
    search_by_MRT = st.multiselect('SELECT ',("East-West Line","North-South Line","North-East Line","Circle Line","Downtown Line"))
    is_room = st.checkbox("Room")
    user_email = st.text_input("Your email address")
    button = st.form_submit_button()
    if button:
        search_by_MRT.append(user_email)
        search_by_MRT.append(is_room)
        search_param_upload(search_by_MRT)
        #search_param(search_by_MRT, is_room)
        #download_search_filter_fromS3()

        st.info("We will notify you once we find the property you are looking for.")
